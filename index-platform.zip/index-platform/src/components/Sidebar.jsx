const NAV = [
  { id: 'dashboard', icon: '⊞', label: 'Dashboard' },
  { id: 'browse',    icon: '🔍', label: 'Browse Challenges' },
  { id: 'submit',    icon: '✦',  label: 'Submit Idea' },
  { id: 'junior',    icon: '🎒', label: 'INDEX Junior' },
];

export default function Sidebar({ view, user, onNav }) {
  return (
    <aside style={{
      width: 220, background: '#0B1E3D', flexShrink: 0,
      display: 'flex', flexDirection: 'column', minHeight: '100vh',
      position: 'sticky', top: 0, zIndex: 10,
    }}>
      <div style={{ padding: '20px 16px 16px', borderBottom: '1px solid rgba(255,255,255,.07)' }}>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 20, color: '#fff' }}>
          INDEX<span style={{ color: '#00D9B4' }}>.</span>
        </div>
      </div>

      {NAV.map(item => (
        <button
          key={item.id}
          onClick={() => onNav(item.id)}
          style={{
            display: 'flex', alignItems: 'center', gap: 10,
            width: '100%', padding: '12px 16px',
            background: view === item.id ? 'rgba(0,217,180,.12)' : 'transparent',
            boxShadow: view === item.id ? 'inset 3px 0 0 #00D9B4' : 'none',
            border: 'none',
            color: view === item.id ? '#00D9B4' : 'rgba(255,255,255,.5)',
            fontSize: 13.5, fontWeight: 500, cursor: 'pointer',
            textAlign: 'left', transition: 'all .15s',
          }}
        >
          <span style={{ fontSize: 15 }}>{item.icon}</span>
          {item.label}
        </button>
      ))}

      <div style={{
        marginTop: 'auto', padding: '14px 16px',
        borderTop: '1px solid rgba(255,255,255,.07)',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          width: 34, height: 34, borderRadius: '50%', background: '#00D9B4',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 13, fontWeight: 700, color: '#04102B', flexShrink: 0,
        }}>
          {user?.initials || 'SA'}
        </div>
        <div style={{ overflow: 'hidden' }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {user?.name || 'Safwan Ahmed'}
          </div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,.4)' }}>{user?.role || 'Student'}</div>
        </div>
      </div>
    </aside>
  );
}
