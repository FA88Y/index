import { useState } from 'react';
import { TYPE_COLORS } from '../data';

export default function IdeaCard({ idea, onOpen }) {
  const [hov, setHov] = useState(false);
  const col = TYPE_COLORS[idea.type] || '#64748B';

  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      onClick={() => onOpen(idea)}
      style={{
        background: '#fff',
        border: `1.5px solid ${hov ? '#00D9B4' : '#E2E8F0'}`,
        borderRadius: 16,
        padding: '20px 20px 16px',
        cursor: 'pointer',
        transition: 'all 0.2s',
        transform: hov ? 'translateY(-3px)' : 'none',
        boxShadow: hov ? '0 10px 28px rgba(0,217,180,.12)' : '0 2px 8px rgba(15,29,56,.05)',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <span style={{
          padding: '3px 10px', borderRadius: 999,
          background: `${col}18`, color: col,
          fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
        }}>
          {idea.type.toUpperCase()}
        </span>
        <span style={{
          fontSize: 12, color: '#00D9B4', fontWeight: 700,
          background: 'rgba(0,217,180,.1)', padding: '3px 10px', borderRadius: 999,
        }}>
          {idea.match}% match
        </span>
      </div>

      <div style={{
        fontFamily: 'Syne, sans-serif', fontSize: 14, fontWeight: 700,
        color: '#0F1D38', marginBottom: 7, lineHeight: 1.4, minHeight: 40,
      }}>
        {idea.title}
      </div>

      <div style={{
        fontSize: 12.5, color: '#64748B', lineHeight: 1.6, marginBottom: 12,
        overflow: 'hidden', display: '-webkit-box',
        WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
      }}>
        {idea.desc}
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginBottom: 12 }}>
        {idea.skills.slice(0, 3).map(s => (
          <span key={s} style={{
            padding: '3px 9px', borderRadius: 999,
            background: '#F4F7FC', color: '#64748B',
            fontSize: 11, border: '1px solid #E2E8F0',
          }}>{s}</span>
        ))}
        {idea.skills.length > 3 && (
          <span style={{ fontSize: 11, color: '#64748B', padding: '3px 0' }}>+{idea.skills.length - 3}</span>
        )}
      </div>

      <div style={{
        borderTop: '1px solid #E2E8F0', paddingTop: 10,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <span style={{ fontSize: 11, color: '#64748B' }}>{idea.team}/{idea.max} members · {idea.posted}</span>
        <span style={{ fontSize: 12, color: '#00D9B4', fontWeight: 600 }}>View →</span>
      </div>
    </div>
  );
}
