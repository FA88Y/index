import { useState } from 'react';

import Home      from './pages/Home';
import Auth      from './pages/Auth';
import Dashboard from './pages/Dashboard';
import Browse    from './pages/Browse';
import Detail    from './pages/Detail';
import Submit    from './pages/Submit';
import Junior    from './pages/Junior';

export default function App() {
  const [view,    setView]    = useState('home');   // home | dashboard | browse | detail | submit | junior
  const [user,    setUser]    = useState(null);     // null = logged out
  const [auth,    setAuth]    = useState(null);     // null | 'login' | 'signup'
  const [selIdea, setSelIdea] = useState(null);     // the idea object shown in Detail

  /* ── Auth handlers ─────────────────────────── */
  const openAuth = mode => setAuth(mode);

  const handleLogin = userData => {
    setUser(userData);
    setAuth(null);
    setView('dashboard');
  };

  /* ── Navigation ─────────────────────────────── */
  const navTo = target => {
    if (target === 'submit') setSelIdea(null); // reset any selected idea
    setView(target);
    window.scrollTo(0, 0);
  };

  const openIdea = idea => {
    setSelIdea(idea);
    setView('detail');
    window.scrollTo(0, 0);
  };

  /* ── Auth screen (full-page takeover) ─────── */
  if (auth) return (
    <Auth
      mode={auth}
      onLogin={handleLogin}
      onSwitch={mode => setAuth(mode)}
    />
  );

  /* ── Public home ─────────────────────────── */
  if (view === 'home') return <Home onAuth={openAuth} />;

  /* ── Authenticated views ─────────────────── */
  const shared = { user, view, onNav: navTo };

  return (
    <>
      {view === 'dashboard' && <Dashboard {...shared} onOpenIdea={openIdea} />}
      {view === 'browse'    && <Browse    {...shared} onOpenIdea={openIdea} />}
      {view === 'detail'    && <Detail    {...shared} idea={selIdea} onSubmit={() => navTo('submit')} />}
      {view === 'submit'    && <Submit    {...shared} />}
      {view === 'junior'    && <Junior    {...shared} />}
    </>
  );
}
