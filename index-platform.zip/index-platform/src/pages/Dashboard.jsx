import Sidebar from '../components/Sidebar';
import IdeaCard from '../components/IdeaCard';
import { IDEAS } from '../data';

const STATS = [
  ['12',  'Skill Matches',   '🎯', '#00D9B4'],
  ['2',   'Active Projects', '⚡', '#4B7FFF'],
  ['74%', 'Profile Score',   '📈', '#FF6B4A'],
  ['8',   'Connections',     '🔗', '#A855F7'],
];

export default function Dashboard({ user, view, onNav, onOpenIdea }) {
  const top3 = [...IDEAS].sort((a, b) => b.match - a.match).slice(0, 3);

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar view={view} user={user} onNav={onNav} />

      <main style={{ flex: 1, padding: '36px 40px', background: '#F4F7FC', overflowY: 'auto' }}>

        {/* Header */}
        <div style={{ marginBottom: 30 }}>
          <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 24, fontWeight: 800, color: '#0F1D38' }}>
            Good morning, {user?.name?.split(' ')[0] || 'Safwan'}! 👋
          </h1>
          <p style={{ fontSize: 14, color: '#64748B', marginTop: 4 }}>Here are challenges matching your profile</p>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 32 }}>
          {STATS.map(([v, l, icon, col]) => (
            <div key={l} style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 16, padding: '18px 20px' }}>
              <div style={{ fontSize: 22, marginBottom: 8 }}>{icon}</div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 800, color: col }}>{v}</div>
              <div style={{ fontSize: 13, color: '#64748B', marginTop: 2 }}>{l}</div>
            </div>
          ))}
        </div>

        {/* Top matches */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 17, fontWeight: 700, color: '#0F1D38' }}>Recommended for You</div>
          <button onClick={() => onNav('browse')} style={{ fontSize: 13, color: '#00D9B4', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600, padding: 0 }}>
            View All →
          </button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginBottom: 30 }}>
          {top3.map(idea => <IdeaCard key={idea.id} idea={idea} onOpen={onOpenIdea} />)}
        </div>

        {/* Profile completion */}
        <div style={{ background: 'linear-gradient(135deg,#04102B 0%,#0B1E3D 100%)', borderRadius: 20, padding: '26px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 20 }}>
          <div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 15, fontWeight: 700, color: '#fff', marginBottom: 4 }}>Your profile is 74% complete</div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,.5)' }}>Add portfolio links and research interests for better matches</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <div>
              <div style={{ width: 120, height: 7, background: 'rgba(255,255,255,.15)', borderRadius: 999, overflow: 'hidden', marginBottom: 6 }}>
                <div style={{ width: '74%', height: '100%', background: '#00D9B4', borderRadius: 999 }} />
              </div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,.4)', textAlign: 'right' }}>74%</div>
            </div>
            <button style={{ padding: '9px 18px', background: '#00D9B4', border: 'none', borderRadius: 999, color: '#04102B', fontSize: 13, fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap' }}>
              Complete Profile
            </button>
          </div>
        </div>

      </main>
    </div>
  );
}
