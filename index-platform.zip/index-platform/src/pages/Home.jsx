import HeroCanvas from '../components/HeroCanvas';

const FEATURES = [
  ['🧠', 'AI Skill Matching',       'Matched to projects based on your skills and interests automatically.'],
  ['⚡', 'Industry Challenges',      'Real UAE company problems posted and ready for collaborative solutions.'],
  ['🔗', 'Research Hub',            'Connect research to industry partners, students, and funding.'],
  ['📚', 'Learning Paths',          'Personalized course recommendations to close skill gaps instantly.'],
  ['🌐', 'Knowledge Network',       'Every challenge linked to related research papers and case studies.'],
  ['🚀', 'Team Workspace',          'Share resources, discuss ideas, and track milestones together.'],
];

const STATS = [
  ['247',   'Active Challenges'],
  ['1,842', 'Collaborators'],
  ['34',    'Universities'],
  ['89',    'Industry Partners'],
];

export default function Home({ onAuth }) {
  return (
    <div style={{ background: '#04102B' }}>

      {/* NAV */}
      <nav style={{
        background: 'rgba(4,16,43,.95)', padding: '16px 48px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        borderBottom: '1px solid rgba(255,255,255,.05)',
        position: 'sticky', top: 0, zIndex: 100,
        backdropFilter: 'blur(14px)',
      }}>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22, color: '#fff' }}>
          INDEX<span style={{ color: '#00D9B4' }}>.</span>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={() => onAuth('login')} style={{ padding: '9px 20px', background: 'transparent', border: '1px solid rgba(255,255,255,.25)', borderRadius: 999, color: '#fff', fontSize: 14, cursor: 'pointer' }}>
            Sign In
          </button>
          <button onClick={() => onAuth('signup')} style={{ padding: '9px 20px', background: '#00D9B4', border: 'none', borderRadius: 999, color: '#04102B', fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>
            Get Started
          </button>
        </div>
      </nav>

      {/* HERO */}
      <div style={{ height: '90vh', minHeight: 560, display: 'flex', alignItems: 'center', position: 'relative', overflow: 'hidden' }}>
        <HeroCanvas />
        <div style={{ position: 'relative', zIndex: 2, padding: '0 60px', maxWidth: 680 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 11, fontWeight: 700, letterSpacing: '.14em', textTransform: 'uppercase', color: '#00D9B4', marginBottom: 24 }}>
            <div style={{ width: 26, height: 1.5, background: '#00D9B4' }} />
            Industry · Academia · Research · Innovation
          </div>
          <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(46px,6.5vw,80px)', fontWeight: 800, lineHeight: 1.04, letterSpacing: '-2.5px', color: '#fff', marginBottom: 24 }}>
            Where<br />Problems<br /><span style={{ color: '#00D9B4' }}>Meet Solutions.</span>
          </h1>
          <p style={{ fontSize: 18, fontWeight: 300, color: 'rgba(255,255,255,.55)', maxWidth: 500, lineHeight: 1.75, marginBottom: 42 }}>
            INDEX connects companies, universities, researchers, and students — turning UAE's real-world challenges into collaborative breakthroughs.
          </p>
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <button onClick={() => onAuth('signup')} style={{ padding: '14px 32px', background: '#00D9B4', border: 'none', borderRadius: 999, color: '#04102B', fontSize: 16, fontWeight: 700, cursor: 'pointer' }}>
              Join the Ecosystem
            </button>
            <button onClick={() => onAuth('login')} style={{ padding: '13px 32px', background: 'transparent', border: '1.5px solid rgba(255,255,255,.3)', borderRadius: 999, color: '#fff', fontSize: 16, cursor: 'pointer' }}>
              Sign In
            </button>
          </div>
        </div>
      </div>

      {/* STATS */}
      <div style={{ background: '#fff', padding: '28px 60px', display: 'flex', justifyContent: 'center', gap: 80, flexWrap: 'wrap', borderBottom: '1px solid #E2E8F0' }}>
        {STATS.map(([v, l]) => (
          <div key={l} style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 36, fontWeight: 800, color: '#0F1D38' }}>{v}</div>
            <div style={{ fontSize: 13, color: '#64748B', marginTop: 4 }}>{l}</div>
          </div>
        ))}
      </div>

      {/* FEATURES */}
      <div style={{ background: '#F4F7FC', padding: '96px 60px' }}>
        <div style={{ textAlign: 'center', marginBottom: 60 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.15em', textTransform: 'uppercase', color: '#00D9B4', marginBottom: 14 }}>Platform Features</div>
          <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(28px,4vw,44px)', fontWeight: 800, letterSpacing: '-1px', color: '#0F1D38' }}>
            Everything to Collaborate,<br />All in One Place
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 18, maxWidth: 1080, margin: '0 auto' }}>
          {FEATURES.map(([icon, title, desc]) => (
            <div key={title} style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 18, padding: '28px 26px' }}>
              <div style={{ fontSize: 28, marginBottom: 14 }}>{icon}</div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 15, fontWeight: 700, color: '#0F1D38', marginBottom: 8 }}>{title}</div>
              <div style={{ fontSize: 13, color: '#64748B', lineHeight: 1.65 }}>{desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{ background: '#04102B', padding: '100px 60px', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', width: 500, height: 500, borderRadius: '50%', background: 'radial-gradient(circle,rgba(0,217,180,.13) 0%,transparent 70%)', top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }} />
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.15em', textTransform: 'uppercase', color: '#00D9B4', marginBottom: 16 }}>Get Started</div>
          <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(30px,5vw,60px)', fontWeight: 800, color: '#fff', letterSpacing: '-2px', lineHeight: 1.05, marginBottom: 18 }}>
            Ready to Join<br />the Ecosystem?
          </h2>
          <p style={{ fontSize: 17, color: 'rgba(255,255,255,.5)', marginBottom: 40, maxWidth: 440, marginLeft: 'auto', marginRight: 'auto' }}>
            Student, researcher, company, or university — INDEX has a place for you.
          </p>
          <div style={{ display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button onClick={() => onAuth('signup')} style={{ padding: '14px 32px', background: '#00D9B4', border: 'none', borderRadius: 999, color: '#04102B', fontSize: 16, fontWeight: 700, cursor: 'pointer' }}>
              Create Your Profile
            </button>
            <button onClick={() => onAuth('signup')} style={{ padding: '13px 32px', background: 'transparent', border: '1.5px solid rgba(255,255,255,.3)', borderRadius: 999, color: '#fff', fontSize: 16, cursor: 'pointer' }}>
              Post a Challenge
            </button>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div style={{ background: '#020B1C', padding: '28px 60px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 18, color: '#fff' }}>
          INDEX<span style={{ color: '#00D9B4' }}>.</span>
        </div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,.25)' }}>© 2025 INDEX · Where Problems Meet Solutions</div>
      </div>

    </div>
  );
}
