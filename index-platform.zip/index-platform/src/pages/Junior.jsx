import Sidebar from '../components/Sidebar';

export default function Junior({ user, view, onNav }) {
  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar view={view} user={user} onNav={onNav} />

      <main style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#F4F7FC', padding: '60px 80px' }}>
        <div style={{ maxWidth: 600, textAlign: 'center' }}>
          <div style={{ fontSize: 64, marginBottom: 20 }}>🎒</div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 999, padding: '6px 16px', fontSize: 12, fontWeight: 600, color: '#4B7FFF', marginBottom: 20 }}>
            ✦ Coming Soon
          </div>
          <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 42, fontWeight: 800, color: '#0F1D38', letterSpacing: '-1px', marginBottom: 16 }}>
            INDEX Junior
          </h1>
          <p style={{ fontSize: 16, color: '#64748B', lineHeight: 1.8, marginBottom: 12 }}>
            Empowering school students to engage with real-world challenges, guided by university mentors and industry professionals.
          </p>
          <p style={{ fontSize: 14, color: '#64748B', lineHeight: 1.75, marginBottom: 36 }}>
            INDEX Junior provides age-appropriate challenges, hands-on project guides, mentorship from researchers, and a pathway for young innovators to build real skills before they begin their degrees.
          </p>
          <button style={{ padding: '14px 36px', background: '#00D9B4', border: 'none', borderRadius: 999, color: '#04102B', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>
            Join the Waitlist
          </button>
        </div>
      </main>
    </div>
  );
}
