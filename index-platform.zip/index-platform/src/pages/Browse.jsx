import { useState } from 'react';
import Sidebar from '../components/Sidebar';
import IdeaCard from '../components/IdeaCard';
import { IDEAS } from '../data';

const FILTERS = ['All', 'Industry', 'Research', 'Academia'];

export default function Browse({ user, view, onNav, onOpenIdea }) {
  const [filt, setFilt] = useState('All');
  const [srch, setSrch] = useState('');

  const filtered = IDEAS.filter(i =>
    (filt === 'All' || i.type === filt) &&
    (!srch || i.title.toLowerCase().includes(srch.toLowerCase()) ||
      i.skills.some(s => s.toLowerCase().includes(srch.toLowerCase())))
  );

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar view={view} user={user} onNav={onNav} />

      <main style={{ flex: 1, padding: '36px 40px', background: '#F4F7FC' }}>
        <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 24, fontWeight: 800, color: '#0F1D38', marginBottom: 4 }}>Browse Challenges</h1>
        <p style={{ fontSize: 14, color: '#64748B', marginBottom: 26 }}>{filtered.length} open challenges · Find your next collaboration</p>

        {/* Search + filters */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 26, flexWrap: 'wrap' }}>
          <input
            value={srch}
            onChange={e => setSrch(e.target.value)}
            placeholder="Search by title, skill, or keyword..."
            style={{ flex: 1, minWidth: 200, padding: '10px 14px', border: '1.5px solid #E2E8F0', borderRadius: 12, fontSize: 14, color: '#0F1D38', background: '#fff' }}
          />
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {FILTERS.map(f => (
              <button
                key={f}
                onClick={() => setFilt(f)}
                style={{ padding: '9px 18px', borderRadius: 999, border: `1.5px solid ${filt === f ? '#00D9B4' : '#E2E8F0'}`, background: filt === f ? 'rgba(0,217,180,.1)' : '#fff', color: filt === f ? '#00D9B4' : '#64748B', fontSize: 13, fontWeight: filt === f ? 600 : 400, cursor: 'pointer', transition: 'all .15s' }}>
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        {filtered.length > 0 ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 14 }}>
            {filtered.map(idea => <IdeaCard key={idea.id} idea={idea} onOpen={onOpenIdea} />)}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '60px 0', color: '#64748B' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 18, fontWeight: 700, color: '#0F1D38', marginBottom: 8 }}>No challenges found</div>
            <div style={{ fontSize: 14 }}>Try a different search or filter</div>
          </div>
        )}
      </main>
    </div>
  );
}
