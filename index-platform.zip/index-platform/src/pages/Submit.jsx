import { useState } from 'react';
import Sidebar from '../components/Sidebar';
import { SKILLS_DB, COURSE_MAP } from '../data';

const inp = { width: '100%', padding: '10px 13px', border: '1.5px solid #E2E8F0', borderRadius: 10, fontSize: 14, display: 'block', color: '#0F1D38', background: '#fff' };
const lbl = { display: 'block', fontSize: 13, fontWeight: 600, color: '#0F1D38', marginBottom: 6 };
const STEPS = ['Basic Info', 'The Problem', 'Skills & Team', 'References'];

export default function Submit({ user, view, onNav }) {
  const [step,    setStep]    = useState(1);
  const [done,    setDone]    = useState(false);
  const [type,    setType]    = useState('Industry');
  const [skills,  setSkills]  = useState([]);
  const [skillIn, setSkillIn] = useState('');
  const [team,    setTeam]    = useState(4);
  const [tl,      setTl]      = useState('3 months');

  const addSkill = s => { if (s && !skills.includes(s)) setSkills(prev => [...prev, s]); setSkillIn(''); };
  const rmSkill  = s => setSkills(prev => prev.filter(x => x !== s));

  const recs = skills.filter(s => COURSE_MAP[s]).map(s => COURSE_MAP[s]);

  if (done) return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar view={view} user={user} onNav={onNav} />
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#F4F7FC' }}>
        <div style={{ textAlign: 'center', maxWidth: 420, padding: 40 }}>
          <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'rgba(0,217,180,.1)', border: '2px solid #00D9B4', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36, margin: '0 auto 24px' }}>🎉</div>
          <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 28, fontWeight: 800, color: '#0F1D38', marginBottom: 12 }}>Idea Submitted!</div>
          <div style={{ fontSize: 15, color: '#64748B', lineHeight: 1.7, marginBottom: 32 }}>Your challenge is live on INDEX. Our AI is already finding the best collaborators for your project.</div>
          <button onClick={() => onNav('browse')} style={{ width: '100%', padding: '12px 0', background: '#00D9B4', border: 'none', borderRadius: 12, color: '#04102B', fontSize: 15, fontWeight: 700, cursor: 'pointer', marginBottom: 12 }}>Browse All Challenges</button>
          <button onClick={() => onNav('dashboard')} style={{ width: '100%', padding: '11px 0', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 12, color: '#64748B', fontSize: 14, cursor: 'pointer' }}>Back to Dashboard</button>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar view={view} user={user} onNav={onNav} />

      <main style={{ flex: 1, padding: '36px', background: '#F4F7FC', overflowY: 'auto' }}>
        <div style={{ maxWidth: 660, margin: '0 auto' }}>
          <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 24, fontWeight: 800, color: '#0F1D38', marginBottom: 4 }}>Submit an Idea</h1>
          <p style={{ fontSize: 14, color: '#64748B', marginBottom: 34 }}>Share a challenge or research opportunity with the INDEX community</p>

          {/* Stepper */}
          <div style={{ display: 'flex', marginBottom: 38, position: 'relative' }}>
            <div style={{ position: 'absolute', top: 15, left: '8%', right: '8%', height: 2, background: '#E2E8F0', zIndex: 0 }} />
            <div style={{ position: 'absolute', top: 15, left: '8%', width: `${((step - 1) / (STEPS.length - 1)) * 84}%`, height: 2, background: '#00D9B4', zIndex: 0, transition: 'width .3s' }} />
            {STEPS.map((s, i) => {
              const done2 = step > i + 1, active = step === i + 1;
              return (
                <div key={s} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative', zIndex: 1 }}>
                  <div style={{ width: 30, height: 30, borderRadius: '50%', background: done2 ? '#00D9B4' : active ? '#04102B' : '#fff', border: `2px solid ${done2 || active ? '#00D9B4' : '#E2E8F0'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: done2 ? '#04102B' : active ? '#fff' : '#64748B' }}>
                    {done2 ? '✓' : i + 1}
                  </div>
                  <div style={{ fontSize: 11, color: active ? '#00D9B4' : '#64748B', marginTop: 6, fontWeight: active ? 600 : 400, textAlign: 'center', whiteSpace: 'nowrap' }}>{s}</div>
                </div>
              );
            })}
          </div>

          <div style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 20, padding: '32px 36px' }}>

            {/* Step 1 */}
            {step === 1 && (
              <>
                <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 17, fontWeight: 700, color: '#0F1D38', marginBottom: 22 }}>About Your Idea</h2>
                <label style={lbl}>Type</label>
                <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
                  {['Industry', 'Academia', 'Research'].map(t => (
                    <button key={t} onClick={() => setType(t)} style={{ padding: '8px 20px', borderRadius: 999, border: `1.5px solid ${type === t ? '#00D9B4' : '#E2E8F0'}`, background: type === t ? 'rgba(0,217,180,.1)' : '#fff', color: type === t ? '#00D9B4' : '#64748B', fontSize: 13, fontWeight: type === t ? 600 : 400, cursor: 'pointer', transition: 'all .15s' }}>
                      {t}
                    </button>
                  ))}
                </div>
                <label style={lbl}>Topic / Title</label>
                <input style={{ ...inp, marginBottom: 18 }} placeholder="e.g. AI-Driven Water Management System for UAE Agriculture" />
                <label style={lbl}>Description</label>
                <textarea rows={4} style={inp} placeholder="Briefly describe the challenge and what a solution would look like..." />
              </>
            )}

            {/* Step 2 */}
            {step === 2 && (
              <>
                <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 17, fontWeight: 700, color: '#0F1D38', marginBottom: 22 }}>The Problem</h2>
                <label style={lbl}>Problem Statement</label>
                <textarea rows={4} style={{ ...inp, marginBottom: 18 }} placeholder="What specific problem are you trying to solve? Be as precise as possible..." />
                <label style={lbl}>Current Solutions & Limitations</label>
                <textarea rows={3} style={inp} placeholder="What solutions already exist? Why aren't they sufficient?" />
              </>
            )}

            {/* Step 3 */}
            {step === 3 && (
              <>
                <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 17, fontWeight: 700, color: '#0F1D38', marginBottom: 22 }}>Skills & Team</h2>
                <label style={lbl}>Skills Required</label>
                <input
                  value={skillIn}
                  onChange={e => setSkillIn(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addSkill(skillIn.trim()); } }}
                  placeholder="Type a skill and press Enter, or click below"
                  style={{ ...inp, marginBottom: 10 }}
                />
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 12 }}>
                  {SKILLS_DB.filter(s => !skills.includes(s)).slice(0, 9).map(s => (
                    <button key={s} onClick={() => addSkill(s)} style={{ padding: '4px 11px', borderRadius: 999, border: '1px solid #E2E8F0', background: '#F4F7FC', color: '#64748B', fontSize: 12, cursor: 'pointer' }}>+ {s}</button>
                  ))}
                </div>
                {skills.length > 0 && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7, marginBottom: 18 }}>
                    {skills.map(s => (
                      <span key={s} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '5px 12px', borderRadius: 999, background: 'rgba(0,217,180,.1)', border: '1.5px solid #00D9B4', color: '#00D9B4', fontSize: 13, fontWeight: 600 }}>
                        {s}
                        <span onClick={() => rmSkill(s)} style={{ cursor: 'pointer', fontWeight: 700, lineHeight: 1 }}>×</span>
                      </span>
                    ))}
                  </div>
                )}
                {recs.length > 0 && (
                  <div style={{ background: '#F4F7FC', border: '1.5px solid #E2E8F0', borderRadius: 14, padding: '14px 18px', marginBottom: 18 }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: '#00D9B4', marginBottom: 10, letterSpacing: '.1em', textTransform: 'uppercase' }}>✦ AI Course Recommendations</div>
                    {recs.map(c => (
                      <div key={c} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: '#0F1D38', marginBottom: 6 }}>
                        <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#00D9B4', flexShrink: 0 }} />{c}
                      </div>
                    ))}
                  </div>
                )}
                <label style={lbl}>Team Size (max members)</label>
                <div style={{ display: 'flex', gap: 8 }}>
                  {[2, 3, 4, 5, 6, 8].map(n => (
                    <button key={n} onClick={() => setTeam(n)} style={{ width: 42, height: 42, borderRadius: 10, border: `1.5px solid ${team === n ? '#00D9B4' : '#E2E8F0'}`, background: team === n ? 'rgba(0,217,180,.1)' : '#fff', color: team === n ? '#00D9B4' : '#64748B', fontWeight: team === n ? 700 : 400, cursor: 'pointer', fontSize: 14 }}>
                      {n}
                    </button>
                  ))}
                </div>
              </>
            )}

            {/* Step 4 */}
            {step === 4 && (
              <>
                <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 17, fontWeight: 700, color: '#0F1D38', marginBottom: 22 }}>Research & References</h2>
                <label style={lbl}>Related Research Paper</label>
                <input style={{ ...inp, marginBottom: 18 }} placeholder="URL or DOI (e.g. https://arxiv.org/abs/...)" />
                <label style={lbl}>Related Current Work</label>
                <input style={{ ...inp, marginBottom: 20 }} placeholder="Link to existing work, repository, or case study" />
                <label style={lbl}>Expected Timeline</label>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {['1 month', '3 months', '6 months', '1 year'].map(t => (
                    <button key={t} onClick={() => setTl(t)} style={{ padding: '8px 18px', borderRadius: 999, border: `1.5px solid ${tl === t ? '#00D9B4' : '#E2E8F0'}`, background: tl === t ? 'rgba(0,217,180,.1)' : '#fff', color: tl === t ? '#00D9B4' : '#64748B', fontSize: 13, cursor: 'pointer', fontWeight: tl === t ? 600 : 400 }}>
                      {t}
                    </button>
                  ))}
                </div>
              </>
            )}

            {/* Nav buttons */}
            <div style={{ display: 'flex', gap: 12, marginTop: 30, paddingTop: 22, borderTop: '1px solid #E2E8F0' }}>
              {step > 1 && (
                <button onClick={() => setStep(s => s - 1)} style={{ padding: '11px 20px', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 12, color: '#64748B', fontSize: 14, cursor: 'pointer' }}>← Back</button>
              )}
              {step < 4 ? (
                <button onClick={() => setStep(s => s + 1)} style={{ flex: 1, padding: '12px 0', background: '#00D9B4', border: 'none', borderRadius: 12, color: '#04102B', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>Continue →</button>
              ) : (
                <button onClick={() => setDone(true)} style={{ flex: 1, padding: '12px 0', background: '#00D9B4', border: 'none', borderRadius: 12, color: '#04102B', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>🚀 Submit to INDEX</button>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
