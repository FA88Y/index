import { useState } from 'react';
import { ROLES, SKILLS_DB } from '../data';

const inp = { width: '100%', padding: '10px 13px', border: '1.5px solid #E2E8F0', borderRadius: 10, fontSize: 14, display: 'block', color: '#0F1D38', background: '#fff' };
const lbl = { display: 'block', fontSize: 13, fontWeight: 600, color: '#0F1D38', marginBottom: 6 };
const PBtn = { width: '100%', padding: '12px 0', background: '#00D9B4', border: 'none', borderRadius: 12, color: '#04102B', fontSize: 15, fontWeight: 700, cursor: 'pointer' };
const GBtn = { padding: '11px 20px', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 12, color: '#64748B', fontSize: 14, cursor: 'pointer' };

export default function Auth({ mode, onLogin, onSwitch }) {
  const [step, setStep]   = useState(1);
  const [role, setRole]   = useState('');
  const [nm,   setNm]     = useState('');
  const [em,   setEm]     = useState('');
  const [og,   setOg]     = useState('');
  const [skills, setSkills] = useState([]);

  const toggleSkill = s => setSkills(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);

  const doLogin = () => {
    const name = nm.trim() || 'Safwan Ahmed';
    onLogin({
      name,
      role: role || 'Student',
      org: og || 'UAE University',
      initials: name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2),
      skills: skills.length ? skills : ['Machine Learning', 'Python', 'UI/UX Design'],
    });
  };

  return (
    <div style={{ background: 'rgba(4,16,43,.97)', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ background: '#fff', borderRadius: 24, padding: '40px 44px', width: '100%', maxWidth: 480 }}>

        {mode === 'login' ? (
          <>
            <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 26, fontWeight: 800, color: '#0F1D38', marginBottom: 6 }}>Welcome back</div>
            <div style={{ fontSize: 14, color: '#64748B', marginBottom: 28 }}>Sign in to your INDEX account</div>
            <label style={lbl}>Email</label>
            <input style={{ ...inp, marginBottom: 14 }} placeholder="you@email.com" type="email" />
            <label style={lbl}>Password</label>
            <input style={{ ...inp, marginBottom: 24 }} placeholder="••••••••" type="password" />
            <button onClick={doLogin} style={PBtn}>Sign In →</button>
            <div style={{ textAlign: 'center', marginTop: 18, fontSize: 14, color: '#64748B' }}>
              No account?{' '}
              <span style={{ color: '#00D9B4', cursor: 'pointer', fontWeight: 600 }} onClick={() => onSwitch('signup')}>Join INDEX</span>
            </div>
          </>
        ) : (
          <>
            {/* STEP 1 — Role */}
            {step === 1 && (
              <>
                <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 26, fontWeight: 800, color: '#0F1D38', marginBottom: 6 }}>Join INDEX</div>
                <div style={{ fontSize: 14, color: '#64748B', marginBottom: 22 }}>I am a...</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 22 }}>
                  {ROLES.map(r => (
                    <div key={r.id} onClick={() => setRole(r.label)} style={{ border: `2px solid ${role === r.label ? '#00D9B4' : '#E2E8F0'}`, borderRadius: 14, padding: '16px 14px', cursor: 'pointer', background: role === r.label ? 'rgba(0,217,180,.1)' : '#fff', transition: 'all .15s' }}>
                      <div style={{ fontSize: 24, marginBottom: 6 }}>{r.icon}</div>
                      <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 14, color: '#0F1D38', marginBottom: 4 }}>{r.label}</div>
                      <div style={{ fontSize: 11, color: '#64748B', lineHeight: 1.5 }}>{r.desc}</div>
                    </div>
                  ))}
                </div>
                <button onClick={() => role && setStep(2)} style={{ ...PBtn, opacity: role ? 1 : 0.45 }}>Continue →</button>
                <div style={{ textAlign: 'center', marginTop: 16, fontSize: 14, color: '#64748B' }}>
                  Have an account?{' '}
                  <span style={{ color: '#00D9B4', cursor: 'pointer', fontWeight: 600 }} onClick={() => onSwitch('login')}>Sign In</span>
                </div>
              </>
            )}

            {/* STEP 2 — Details */}
            {step === 2 && (
              <>
                <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 22, fontWeight: 800, color: '#0F1D38', marginBottom: 4 }}>Your Details</div>
                <div style={{ fontSize: 13, color: '#64748B', marginBottom: 22 }}>Setting up your {role} profile</div>
                <label style={lbl}>Full Name</label>
                <input style={{ ...inp, marginBottom: 14 }} placeholder="Your full name" value={nm} onChange={e => setNm(e.target.value)} />
                <label style={lbl}>Email</label>
                <input style={{ ...inp, marginBottom: 14 }} placeholder="you@email.com" type="email" value={em} onChange={e => setEm(e.target.value)} />
                <label style={lbl}>{role === 'Industry' ? 'Company Name' : 'University / Institution'}</label>
                <input style={{ ...inp, marginBottom: 24 }} placeholder={role === 'Industry' ? 'Your company' : 'e.g. UAE University'} value={og} onChange={e => setOg(e.target.value)} />
                <div style={{ display: 'flex', gap: 10 }}>
                  <button onClick={() => setStep(1)} style={GBtn}>← Back</button>
                  <button onClick={() => setStep(3)} style={{ ...PBtn, flex: 1 }}>Continue →</button>
                </div>
              </>
            )}

            {/* STEP 3 — Skills */}
            {step === 3 && (
              <>
                <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 22, fontWeight: 800, color: '#0F1D38', marginBottom: 4 }}>Your Skills</div>
                <div style={{ fontSize: 13, color: '#64748B', marginBottom: 18 }}>Select skills for better project matches</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 26 }}>
                  {SKILLS_DB.map(s => {
                    const sel = skills.includes(s);
                    return (
                      <button key={s} onClick={() => toggleSkill(s)} style={{ padding: '6px 14px', borderRadius: 999, border: `1.5px solid ${sel ? '#00D9B4' : '#E2E8F0'}`, background: sel ? 'rgba(0,217,180,.1)' : '#fff', color: sel ? '#00D9B4' : '#64748B', fontSize: 13, cursor: 'pointer', fontWeight: sel ? 600 : 400, transition: 'all .12s' }}>
                        {s}
                      </button>
                    );
                  })}
                </div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button onClick={() => setStep(2)} style={GBtn}>← Back</button>
                  <button onClick={doLogin} style={{ ...PBtn, flex: 1 }}>🎉 Create Account</button>
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
