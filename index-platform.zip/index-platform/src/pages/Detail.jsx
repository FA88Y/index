import Sidebar from '../components/Sidebar';
import { TYPE_COLORS } from '../data';

export default function Detail({ idea, user, view, onNav, onSubmit }) {
  if (!idea) { onNav('browse'); return null; }
  const col = TYPE_COLORS[idea.type] || '#64748B';

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar view={view} user={user} onNav={onNav} />

      <main style={{ flex: 1, padding: '36px 44px', background: '#F4F7FC', overflowY: 'auto' }}>
        <button onClick={() => onNav('browse')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B', fontSize: 13, display: 'flex', alignItems: 'center', gap: 6, marginBottom: 22, padding: 0 }}>
          ← Back to Browse
        </button>

        {/* Header card */}
        <div style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 20, padding: '32px 36px', marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
            <span style={{ padding: '5px 14px', borderRadius: 999, background: `${col}18`, color: col, fontSize: 12, fontWeight: 700 }}>{idea.type}</span>
            <span style={{ fontFamily: 'Syne, sans-serif', fontSize: 20, fontWeight: 800, color: '#00D9B4' }}>{idea.match}% match</span>
          </div>
          <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 24, fontWeight: 800, color: '#0F1D38', marginBottom: 12, lineHeight: 1.2 }}>{idea.title}</h1>
          <p style={{ fontSize: 15, color: '#64748B', lineHeight: 1.75, marginBottom: 20 }}>{idea.desc}</p>
          <div style={{ display: 'flex', gap: 28, fontSize: 13, color: '#64748B', flexWrap: 'wrap' }}>
            <span>👤 <strong style={{ color: '#0F1D38' }}>{idea.author}</strong> · {idea.org}</span>
            <span>⏰ {idea.posted}</span>
            <span>👥 {idea.team}/{idea.max} members</span>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 290px', gap: 16 }}>
          {/* Left */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 16, padding: '24px 28px' }}>
              <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 16, fontWeight: 700, color: '#0F1D38', marginBottom: 12 }}>Problem Statement</div>
              <p style={{ fontSize: 14, color: '#64748B', lineHeight: 1.8 }}>{idea.problem}</p>
            </div>

            <div style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 16, padding: '24px 28px' }}>
              <div style={{ fontFamily: 'Syne, sans-serif', fontSize: 16, fontWeight: 700, color: '#0F1D38', marginBottom: 12 }}>Skills Required</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 18 }}>
                {idea.skills.map(s => (
                  <span key={s} style={{ padding: '6px 14px', borderRadius: 999, background: 'rgba(0,217,180,.1)', border: '1.5px solid #00D9B4', color: '#00D9B4', fontSize: 13, fontWeight: 600 }}>{s}</span>
                ))}
              </div>

              {idea.courses.length > 0 && (
                <div style={{ borderTop: '1px solid #E2E8F0', paddingTop: 14 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#00D9B4', marginBottom: 10, letterSpacing: '.1em', textTransform: 'uppercase' }}>✦ Suggested Courses for Acquiring Skills</div>
                  {idea.courses.map(c => (
                    <div key={c} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: '#64748B', marginBottom: 8 }}>
                      <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#00D9B4', flexShrink: 0 }} />
                      {c}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <button style={{ width: '100%', padding: '14px 0', background: '#00D9B4', border: 'none', borderRadius: 14, color: '#04102B', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}>
              Apply to Join Team
            </button>

            <div style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 16, padding: '18px 20px' }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '.1em', marginBottom: 12 }}>Posted By</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(0,217,180,.1)', border: '1.5px solid #00D9B4', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>👤</div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#0F1D38' }}>{idea.author}</div>
                  <div style={{ fontSize: 12, color: '#64748B' }}>{idea.role} · {idea.org}</div>
                </div>
              </div>
            </div>

            <div style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 16, padding: '18px 20px' }}>
              {[['👥', 'Team', `${idea.team} of ${idea.max} filled`], ['📄', 'Papers', `${idea.papers} linked`], ['⏰', 'Posted', idea.posted], ['✅', 'Status', idea.status]].map(([icon, label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                  <span style={{ fontSize: 13, color: '#64748B' }}>{icon} {label}</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: '#0F1D38' }}>{val}</span>
                </div>
              ))}
            </div>

            <button onClick={onSubmit} style={{ padding: '11px 20px', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 12, color: '#64748B', fontSize: 13, cursor: 'pointer', width: '100%' }}>
              Submit Similar Idea
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
