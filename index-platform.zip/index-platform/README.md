# INDEX Platform

> Where Problems Meet Solutions — connecting Industry, Academia, Research, and Students.

## ⚡ Quick Start (run locally)

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Open http://localhost:5173
```

## 🚀 Deploy Live in 5 Minutes (FREE via Vercel)

### Step 1 — Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/index-platform.git
git push -u origin main
```

### Step 2 — Deploy on Vercel
1. Go to **https://vercel.com** → Sign up with GitHub (free)
2. Click **"Add New Project"**
3. Import your `index-platform` repository
4. Leave all settings as default — Vercel auto-detects Vite
5. Click **"Deploy"**

✅ Your site is live at `https://index-platform.vercel.app` (or similar)

### Step 3 — Custom Domain (e.g. indexplatform.com)
1. Buy a domain on **Namecheap**, **GoDaddy**, or **Cloudflare Domains** (~$10–15/yr)
2. In Vercel: Project → Settings → Domains → Add Domain
3. Follow Vercel's DNS instructions (takes ~5 mins)

---

## 📁 Project Structure

```
index-platform/
├── index.html              ← HTML entry point
├── vite.config.js          ← Vite config
├── package.json
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx            ← React entry
    ├── App.jsx             ← Router / global state
    ├── index.css           ← Global styles
    ├── data.js             ← All platform data (ideas, skills, etc.)
    ├── components/
    │   ├── HeroCanvas.jsx  ← Animated network hero
    │   ├── IdeaCard.jsx    ← Challenge card component
    │   └── Sidebar.jsx     ← Dashboard sidebar
    └── pages/
        ├── Home.jsx        ← Landing page
        ├── Auth.jsx        ← Login / Signup (3-step)
        ├── Dashboard.jsx   ← User dashboard
        ├── Browse.jsx      ← Browse & filter challenges
        ├── Detail.jsx      ← Challenge detail view
        ├── Submit.jsx      ← 4-step idea submission form
        └── Junior.jsx      ← INDEX Junior page
```

## 🏗️ Build for Production

```bash
npm run build
# Output goes to /dist — ready to upload anywhere
```

## 🛠️ Tech Stack

- **React 18** — UI framework
- **Vite** — blazing-fast build tool
- **Canvas API** — animated hero network
- **Google Fonts** — Syne + DM Sans

## ✏️ How to Add Real Challenges

Edit `src/data.js` — add objects to the `IDEAS` array following the existing schema.

## 📧 Contact / Questions

Built for the INDEX startup. Add your contact info here.
